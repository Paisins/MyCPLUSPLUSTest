#include <iostream>

namespace my_print
{
    void print(const char *str)
    {
        std::cout << "my_print: " << str << std::endl;
    }
}
